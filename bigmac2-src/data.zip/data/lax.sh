#!/bin/sh

#  launchapp.sh
#  bigmac2
#
#  Created by starplayrx on 12/31/20.
#  aka LAX
#  Launch App by Todd Bruss (c) 2020
#
"$1" > /dev/null 2>&1 &
